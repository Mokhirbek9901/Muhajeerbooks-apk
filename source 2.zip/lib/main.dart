
import 'package:flutter/material.dart';

void main() => runApp(const MuhajeerBooksApp());

class MuhajeerBooksApp extends StatelessWidget {
  const MuhajeerBooksApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Muhajeer Books',
      home: Scaffold(
        appBar: AppBar(title: const Text('Muhajeer Books')),
        body: const Center(child: Text('Assalomu alaykum, Bek! Muhajeer Books ilovasi tayyor!')),
      ),
    );
  }
}

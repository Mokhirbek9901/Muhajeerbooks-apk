
import 'package:flutter/material.dart';

void main() => runApp(const MuhajeerBooksApp());

class MuhajeerBooksApp extends StatelessWidget {
  const MuhajeerBooksApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'MuhajeerBooks',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFFF9800)),
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final books = [
      ('Ta’sir psixologiyasi', '15 000 W'),
      ('Ochlik', '15 000 W'),
      ('Beparvolikning nozik san’ati', '15 000 W'),
      ('Xalqa', '15 000 W'),
      ('Qimorboz', '15 000 W'),
      ('Muqaddima', '15 000 W'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('MuhajeerBooks'), centerTitle: true),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Kutub do‘koni ilovasi — katalogni keyin o‘zingiz to‘ldirasiz.', style: TextStyle(fontSize: 16)),
          const SizedBox(height: 16),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: .72,
            ),
            itemCount: books.length,
            itemBuilder: (context, i) {
              final title = books[i].$1;
              final price = books[i].$2;
              return Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.black12),
                ),
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Container(
                        decoration: BoxDecoration(color: Colors.black12, borderRadius: BorderRadius.circular(12)),
                        alignment: Alignment.center,
                        child: const Text('Muqova', style: TextStyle(color: Colors.black45)),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600)),
                    const SizedBox(height: 4),
                    Text(price, style: const TextStyle(color: Colors.orange, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 4),
                    ElevatedButton(onPressed: () {}, child: const Text('Savatga')),
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
